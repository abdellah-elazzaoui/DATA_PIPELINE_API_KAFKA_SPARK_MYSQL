from confluent_kafka.admin import AdminClient , NewTopic ,KafkaException

class Admin:
    def __init__(self,bootstrap:str):
        self.bootstrap = bootstrap
        self.admin = AdminClient({"bootstrap.servers":self.bootstrap})

    def topic_exist(self,topic:str):
        all_topics = self.admin.list_topics()
        return topic in all_topics.topics

    def add_topic(self,topic:str,partitions:int):
        try:
            new_topic = NewTopic(topic,num_partitions=partitions,replication_factor=1)    
            self.admin.create_topics([new_topic])
            print(f"New Topic {topic} Has been Crated")
        except KafkaException as ke:
            print(f"ERROR KAFKA While Creating New Topic - {str(ke)}")
