from airflow import DAG
from Producer import ProducerClass
from datetime import datetime,timedelta
from airflow.operators.python import PythonOperator
import logging

def getting_data(ti):
    bootstrap = "ed-kafka:29092"
    topic = "users"
    compression_type = "snappy"
    batch_size = 100000
    waiting_time = 10000
    producer = ProducerClass(bootstrap=bootstrap,topic=topic,compression_type=compression_type,batch_size=batch_size,waiting_time=waiting_time)
    getted = producer.get_data(ti)
    if getted:
        logging.info("Task 1 Seccessfully Complited")
    else:
        logging.info("Task 1 Failed !!!")


def send_to_kafka(ti):
    bootstrap = "ed-kafka:29092"
    topic = "users"
    compression_type = "snappy"
    batch_size = 100000
    waiting_time = 10000
    producer = ProducerClass(bootstrap=bootstrap,topic=topic,compression_type=compression_type,batch_size=batch_size,waiting_time=waiting_time)
    sent = producer.send_message(ti)
    if sent:
        logging.info("Task 1 Seccessfully Complited")
        producer.commit()
        ti.xcom_push(key="status",value="succes")
    else:
        logging.info("Task 1 Failed !!!")
        ti.xcom_push(key="status",value="failed")




default_args = {
    "owner":"Abdellah",
    "start_date":datetime(2025,12,1),
    "depends_on_past":False,
    "email_on_failure":False,
    "email_on_retry":False,
    "retries":2,
    "retry_delay":timedelta(minutes=1)
}

with DAG(
    dag_id="KAFKA_STREAM_API",
    default_args=default_args,
    schedule=None,
    catchup=False,
    description="Streming Via Kafka",
    tags=["API","KAFKA","SPARK","MySQL"]
) as dag:
    fetching_task=PythonOperator(
        task_id = "fetching_data",
        python_callable = getting_data
    )

    send_message = PythonOperator(
        task_id = "send_message",
        python_callable = send_to_kafka
    )

    fetching_task >> send_message
    