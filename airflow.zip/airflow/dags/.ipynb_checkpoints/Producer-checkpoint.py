from confluent_kafka import Producer , KafkaException
import requests
import json
import logging
from uuid import uuid4



def delivery_report(err,msg):
    if err is not None:
        print("Failed to Delivery the Message Please Try Again")
    else:
        print(f"Message Seccessfully Delivred key-{msg.key()} partition-{msg.partition()} offset-{msg.offset()}")    

class ProducerClass:
    def __init__(self,bootstrap:str,topic:str,compression_type=None,batch_size=None,waiting_time=None):
        self.bootstrap = bootstrap
        self.topic = topic
        conf={"bootstrap.servers":self.bootstrap}
        if compression_type:
            conf["compression.type"] = compression_type
        if batch_size :
            conf["batch.size"] = batch_size
        if waiting_time :
            conf["linger.ms"] = waiting_time  

        self.producer = Producer(conf)

    def get_data(self,ti):
        try:
            logging.info("Fetching Data From API ...")
            response = requests.get("https://randomuser.me/api/")
            data = response.json()["results"][0]
            logging.info("User's Data Secssefully Geted")
            if data :
                ti.xcom_push(key="user",value=data)
                logging.info("Data Successfully Pushed to Xcom")
                return True
            return False
        except Exception as e:
            logging.error(f"ERROR - {str(e)}")
            return False

    def send_message(self,ti):
        try:
            message = ti.xcom_pull(key="user",task_ids="fetching_data")
            if message:
                logging.info("Message is ready to send")
                try:
                    self.producer.produce(
                        topic = self.topic,
                        key = str(uuid4()),
                        value = json.dumps(message),
                        on_delivery=delivery_report
                    )
                    self.producer.poll(0)
                    return True
                except KafkaException as KE:
                    logging.error(f"KAFKA ERROR - {str(e)}")   
                except Exception as e:
                    logging.error(f"ERROR Delivery the Message - {str(e)}")    
                return False
        except Exception as e:
            logging.error(f"ERROR - {str(e)}") 
            return False

    def  commit(self):
        self.producer.flush()




